"""Scientific previews of the native rasters and retained sensor endpoints."""
from pathlib import Path
import json,csv
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
H=Path(__file__).resolve().parent;V1=H.with_name('A1_H2_merged_20261102_v1');runs=json.loads((H/'runs.json').read_text());reg=json.loads((H/'registration.json').read_text());regions=list(csv.DictReader((H/'earlier_wall_regions.csv').open()));colors={'earlier':'#d57a28','later':'#187eb0'}
mask=np.genfromtxt(H/'H1_excluded_rays.csv',delimiter=',',names=True);exclude={(int(v['scan_id']),int(v['beam_index'])) for v in mask};points={};stats=[]
for r in runs:
 n=r['name'];a=np.atleast_1d(np.genfromtxt(H/'runs'/n/'rays.csv',delimiter=',',names=True));p=np.atleast_1d(np.genfromtxt(H/'runs'/n/'selected_poses.csv',delimiter=',',names=True));idx=a['scan_id'].astype(int);theta=p['yaw_rad'][idx]
 local=np.c_[p['x_m'][idx]+np.cos(theta)*a['base_x_m']-np.sin(theta)*a['base_y_m'],p['y_m'][idx]+np.sin(theta)*a['base_x_m']+np.cos(theta)*a['base_y_m']];t=np.array(reg['transforms'][n]);world=local@t[:2,:2].T+t[:2,2];keep=a['ignore_for_mapping']==0
 if n=='H1':
  h1_before=world.copy();h1_mask=np.array([(int(v['scan_id']),int(v['beam_index'])) in exclude for v in a]);assert h1_mask.sum()==75;keep&=~h1_mask;h1_after=world[keep]
 keep_for_preview=keep.copy()
 if r['batch']=='later':
  for region in regions:
   inside=(world[:,0]>=float(region['xmin']))&(world[:,0]<float(region['xmax']))&(world[:,1]>=float(region['ymin']))&(world[:,1]<float(region['ymax']));keep_for_preview&=~inside
 points[n]=world[keep_for_preview];stats.append(dict(run=n,valid_endpoints=len(a),trail_exclusions=int((~keep).sum()),later_endpoints_in_earlier_regions_not_displayed=int(np.sum(keep&~keep_for_preview)),preview_endpoints=int(keep_for_preview.sum())))
k=(h1_after[:,0]>-.9)&(h1_after[:,0]<-.75)&(h1_after[:,1]>3.85)&(h1_after[:,1]<4.85);assert not k.any()
(H/'endpoint_preview_audit.json').write_text(json.dumps(dict(H1_trail_remaining_endpoints=0,runs=stats,note='Endpoint diagnostic uses geometric region bounds; native occupancy selection uses cell centers. Ray exclusion is applied before rendering; wall preference is a raster source-selection policy.'),indent=2)+'\n')
plt.rcParams.update({'font.size':10,'axes.titleweight':'semibold'})
def draw_map(ax,source,label,title):
 g=json.loads((H/('evidence_'+label)/'grid.json').read_text());x,y,_=g['origin'];s=g['resolution'];extent=[x,x+g['width']*s,y,y+g['height']*s];im=np.asarray(Image.open(source/('maps_'+label)/'map.pgm'));ax.imshow(im,cmap='gray',vmin=0,vmax=254,extent=extent,origin='upper',interpolation='nearest');ax.set(xlim=(-2.6,2.6),ylim=(-.95,6.15),title=title,xlabel='x (m)',ylabel='y (m)');ax.set_aspect('equal')
def mark(ax):
 for i,r in enumerate(regions):
  x=float(r['xmin']);y=float(r['ymin']);w=float(r['xmax'])-x;h=float(r['ymax'])-y;ax.add_patch(Rectangle((x,y),w,h,fill=False,lw=1.3,ec='#9c3c70'));ax.text(x+w/2,y+h+.09,str(i+1),ha='center',color='#9c3c70',weight='bold')
for label in ['5cm','2p5cm']:
 fig,ax=plt.subplots(figsize=(7,9));draw_map(ax,H,label,'Revised A1–H2 map • '+label.replace('2p5','2.5'));mark(ax);fig.text(.5,.025,'Earlier geometry retained in regions 1–3\nD3 and H1 audited trail rays excluded',ha='center');fig.tight_layout(rect=(0,.065,1,1));fig.savefig(H/('map_preview_'+label+'.png'),dpi=145);plt.close(fig)
 fig,axs=plt.subplots(1,2,figsize=(11,9));draw_map(axs[0],V1,label,'Previous conservative merge');draw_map(axs[1],H,label,'Revised: earlier walls selected');mark(axs[1]);fig.text(.5,.03,'Black: occupied   •   white: observed free   •   gray: unknown\nThe revised map keeps earlier unknown cells as unknown within selected regions.',ha='center');fig.tight_layout(rect=(0,.075,1,1));fig.savefig(H/('map_comparison_'+label+'.png'),dpi=140);plt.close(fig)
fig,ax=plt.subplots(figsize=(7,9))
for r in runs:
 p=points[r['name']];_,ii=np.unique(np.floor(p/.025),axis=0,return_index=True);p=p[ii];ax.scatter(*p.T,s=1,c=colors[r['batch']],alpha=.7)
mark(ax);ax.set(title='Selected endpoint preview • both trails excluded',xlim=(-2.6,2.6),ylim=(-.95,6.15),xlabel='x (m)',ylabel='y (m)');ax.set_aspect('equal');ax.grid(alpha=.15);ax.legend(handles=[Patch(color=colors['earlier'],label='October 31'),Patch(color=colors['later'],label='November 2 outside selected regions')],loc='lower center',bbox_to_anchor=(.5,-.17),frameon=False)
fig.tight_layout(rect=(0,.06,1,1));fig.savefig(H/'selected_endpoints.png',dpi=150);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(7.5,8))
for ax,p,title in [(axs[0],h1_before,'H1 before exclusion'),(axs[1],h1_after,'H1 after exclusion')]:
 ax.scatter(*p.T,s=5,c=colors['later'],alpha=.6);ax.set(title=title,xlim=(-1.18,-.55),ylim=(3.78,4.93),xlabel='Map x (m)',ylabel='Map y (m)');ax.set_aspect('equal');ax.grid(alpha=.2)
axs[0].scatter(*h1_before[h1_mask].T,s=13,c='#ba356c',label='75 excluded returns');axs[0].legend(loc='lower right',fontsize=8);fig.suptitle('Exact H1 trail removal • 42 scans retained',fontsize=13);fig.text(.5,.025,'Exclusions apply to complete rays, including free-space clearing.\nNo new pose adjustment; nearby measured wall returns remain.',ha='center',fontsize=10);fig.tight_layout(rect=(0,.065,1,.95));fig.savefig(H/'H1_trail_before_after.png',dpi=150);plt.close(fig)
print('Verified zero remaining H1 trail endpoints; wrote revised previews')
