# A1–H2 combined map, preserving differences between capture dates

Prepared November 2, 2026, Asia/Seoul. The merge uses **both latest refined bundles**: `A1_D2_refined_20261102_v1` and `D3_H2_refined_20261102_v1`. It retains their selected individual trajectories and internal registrations: **18 passes, 1,171 saved front-LiDAR scans**. The later batch receives one rigid transform into the earlier batch's frame. D3's **1,206 approved trail rays remain excluded**, including both endpoint occupancy and free-space clearing.

The two batches disagree locally. The default map marks direct occupied/free contradictions as **unknown**, preserving the uncertainty instead of drawing an averaged wall. A separate newer-preferred map assumes the November 2 observations describe the current maze wherever they provide a classified cell. Neither original bundle is modified.

## Delivered maps

| Product | 5 cm | 2.5 cm diagnostic version | Meaning |
|---|---|---|---|
| Conservative combined map | [map.yaml](maps_5cm/map.yaml) | [map.yaml](maps_2p5cm/map.yaml) | Direct cross-date occupied/free contradictions remain unknown |
| Newer observations preferred | [newer_preferred.yaml](maps_5cm/newer_preferred.yaml) | [newer_preferred.yaml](maps_2p5cm/newer_preferred.yaml) | Prefer the later classified cell; use earlier evidence where later evidence is absent |
| Occupied union for review | [occupied_union_review.yaml](maps_5cm/occupied_union_review.yaml) | [occupied_union_review.yaml](maps_2p5cm/occupied_union_review.yaml) | Retain both occupied layers; can retain displaced or duplicate walls |
| Earlier batch on common grid | [earlier.yaml](maps_5cm/earlier.yaml) | [earlier.yaml](maps_2p5cm/earlier.yaml) | October 31 evidence |
| Later batch on common grid | [later.yaml](maps_5cm/later.yaml) | [later.yaml](maps_2p5cm/later.yaml) | November 2 evidence after rigid alignment |

Each YAML has an adjacent PGM. Keep them together. Resolution specifies cell size, not established geometric accuracy. The exported maps retain the full observed extent; preview figures crop the display to the maze. Sparse distant returns explain the large unknown border in the full export.

![Map alternatives](map_comparison_5cm.png)

## Confirming the latest inputs and D3 trail removal

The earlier source contains 559 scans; the later source contains 612. The bundled original saves, **selected refined poses**, exported rays and audits match their source bundles byte-for-byte. The earlier geometry is frozen. Every later run uses `later_to_earlier × local_to_batch`, with no new per-run adjustment or scan-pose optimization.

| Earlier pass | Saved scan count | Later pass | Saved scan count |
|---|---:|---|---:|
| A1 | 96 | D3 | 96 |
| B1 | 74 | D4 | 69 |
| B2 | 55 | E1 | 55 |
| B2e | 28 | F1 | 51 |
| C1 | 92 | F2 | 55 |
| C2 | 76 | G1 | 83 |
| D1 | 69 | G2 | 83 |
| D2 | 69 | G3 | 64 |
| — | — | H1 | 42 |
| — | — | H2 | 14 |

D3 uses its latest selected pose override from the refined D3–H2 bundle, whose same-wall span was 2.15 cm. The native renderer invalidates the exact approved robot-frame regions before native ray tracing. All **1,206 scan/beam/range triples** match the approved exclusion audit: 1,194 dense-trail rays plus 12 sparse-companion rays. D3 retains 23,452 valid endpoints from its 24,658 original valid endpoints; all 96 scans remain. Excluded rays become NaN, never maximum-range clearing rays. No additional exclusion is applied to other runs.

The selected sources retain all earlier qualifications: D4_180 and G1's uncertain later relocation are excluded; E1's recovered-save provenance remains; B2, D1, E1 and G3 retain their previously selected saved trajectories. Earlier A1/B2 repeated attempts are validation evidence, not duplicated occupancy contributions. The old unrefined daily-map alignment supplies only an initial search seed, not the final geometry or trajectories.

## The visible line in the blue endpoint image is H1

The user correctly noticed a thin residual line in the middle panel of `epoch_alignment.png`. The region **x = −0.90…−0.75 m, y = 3.85…4.85 m** contains **75 H1 returns across all 42 H1 scans**, and zero endpoints from the other nine later passes. Their median robot-frame location is approximately **(−0.010, +0.174) m**. This is strongly consistent with a separate robot-relative near-field return; its physical source is unverified.

This H1 line is distinct from D3's excluded trail. It remains in the retained-endpoint diagnostic. The region contains **zero occupied cells** in the later layer and all three combined-map policies, at both 5 cm and 2.5 cm. H1 rays and poses were not silently changed. Zero occupied cells does not establish that these returns could never influence upstream scan matching or free-space evidence. A separate H1 exclusion/re-estimation experiment would be a new refinement, rather than this frozen-batch merge.

![Visible line attribution](visible_trail_attribution.png)

An [annotated endpoint comparison](epoch_alignment_annotated.png) distinguishes this diagnostic from the exported occupancy maps. The original unannotated figure is retained as the exact image discussed with the user.

## Registration and what it assumes

The fixed frame is **original saved C1 rotated +90° with no translation**, matching the latest earlier-batch convention. It is not surveyed drawing coordinates. The later frame is original saved D4. The final D4-frame → earlier-frame transform is:

```text
x translation = -0.564091472489 m
y translation = +4.049291847228 m
yaw           = +0.294196259491 degrees
```

Native C++/Ceres fits one SE(2) transform to supported observed perimeter surfaces. Each of the four perimeter features receives equal total weight, each earlier/later run pair equal weight within that feature, and points equal weight within a pair. A 1.5 cm Huber loss limits individual residual influence. Supported 2.5 cm point voxels require at least three distinct saved scans. The solver has rank three and does not hit its search bounds.

The robust perimeter ensemble is selected before inspecting interior agreement. Interior walls are checks, not alignment constraints. There is no scale correction, elastic deformation, wall straightening, drawing-dimension constraint or averaging of two displaced wall positions. Alignment assumes the perimeter provides a useful common reference. A whole-maze shift or residual distortion cannot be separated from coordinate alignment without an independent survey.

Across the **227 initial interior comparisons**, the RMS of pairwise line RMS values is **1.74 cm**, with median pairwise RMS **1.16 cm**. This is a consistency metric, not an accuracy bound. The additional visually identified wall checks below are reported separately and were not included in that initial score or fit selection.

Alternative perimeter fits move later endpoints by up to **2.06 cm at the 95th percentile** relative to the chosen fit; the largest point shift is 5.89 cm among sparse distant observations. These are sensitivity checks, not confidence intervals. The two upper horizontal wall discrepancies keep the same sign under every tested alignment.

## Local disagreements and possible maze changes

Coordinates refer to the merged frame. Negative horizontal-wall displacement means the later surface is lower in y. Comparisons are correlated run pairs; their counts are not independent sample counts.

| Region | Front-LiDAR result | Support and interpretation |
|---|---|---|
| Upper-left horizontal wall, near (−1.63, 3.68) m | Later surface **2.70 cm lower**; 10–90% pair range 2.04–3.68 cm lower | 4 earlier and 5 later runs; 20 comparisons. Alternative alignments give 2.41–3.46 cm lower. Within-batch median separations are 0.35 / 0.72 cm. |
| Upper-right horizontal wall, near (+1.60, 3.62) m | Later surface **5.86 cm lower**; 10–90% pair range 4.51–7.82 cm lower | 4 earlier and 4 later runs; 16 comparisons. Added after visual review, with alignment frozen. Alternatives give 4.46–6.34 cm lower. Within-batch medians are 1.72 / 1.03 cm. |
| Lower-left vertical segment, near (−1.07, 0.41) m | About **4.37 cm** normal separation | Five earlier runs, but **only E1** supplies later support. E1's provenance and lack of later corroboration limit interpretation. |
| Lower-right inner horizontal wall, near (+0.73, 1.54) m | **1.86 cm** normal separation; median angular difference **3.17°** | Six earlier and seven later runs. Earlier within-batch disagreement is already appreciable. |

![Measured wall differences](wall_detail.png)

For the upper-right wall, restricting front observations to the **same viewing side** still gives about **5.14 cm lower** in the later batch: C1/D1/D2 versus D3. This reduces opposite-face ambiguity but has only one qualifying later run. The upper-left region lacks enough common same-side span for the same check; wall-face ambiguity remains there.

Rear-LiDAR observations, withheld from the registration fit, support the direction of the upper-left difference: median **2.27 cm lower** across 2 earlier / 9 later runs. At the upper-right wall the rear result is larger, **9.74 cm lower**, and has only **one earlier run (D1)** versus 8 later runs; it does not independently validate a precise 5.9 cm movement. Other front/rear comparisons also retain discrepancies. Both sensors use the selected front-SLAM trajectories and the same batch transform, so shared pose error and calibration bias remain.

The evidence is compatible with a physical change in the maze, particularly around the upper horizontal walls, but does **not establish that someone moved them**. Residual SLAM distortion, sensor bias, visibility, unmeasured wall thickness and registration uncertainty are alternative contributors. The historical October 31 “5.8 cm corner” check concerned a different comparison; the similar number here does not identify the same error or physical motion.

Additional post-registration checks find small median offsets for the upper-right vertical wall (0.02 cm), middle-right horizontal wall (0.45 cm, only one earlier run), and lower connector (0.90 cm). The north-center vertical wall lacks enough shared supported span. Box edges shorter than the line-support thresholds do not receive a displacement estimate; their raster disagreements remain visible rather than being interpreted as measured movement.

## How disagreements enter the final maps

Native saved-range tracing first generates each run's pass/hit counters on one common grid. Each batch independently keeps the earlier refined-map support policy: an occupied cell needs at least three distinct scan endpoints in one occupied run, or at least two occupied runs with three total endpoint-scan hits. Weak occupied evidence remains unknown. A single strong occupied run contradicted by at least two free runs also remains unknown.

The two dates are then combined as separate evidence layers, rather than pooling all 18 votes and letting the larger batch dominate:

- **Conservative:** occupied/free conflict between dates → unknown. Otherwise retain occupied evidence; unresolved positive evidence blocks conversion to free; retain observed-free evidence where supported.
- **Newer preferred:** use the later classified cell. Later unresolved occupied evidence stays unknown. Otherwise fall back to the earlier state. This product makes an explicit recency assumption; older geometry can remain where the later batch has no evidence.
- **Occupied union:** either batch's occupied state wins. This is a review alternative and may retain two nearby walls.

| Resolution | Earlier occupied / later free | Later occupied / earlier free | Total contradictory cells |
|---|---:|---:|---:|
| 5 cm | 147 | 142 | **289** |
| 2.5 cm | 398 | 451 | **849** |

These are cell counts, not counts of moved walls. Discretization, surface width, viewpoints and registration can create conflicts. Conversely, two displaced occupied cells with no opposite-date free evidence can both survive: the conservative map does not guarantee elimination of every doubled surface. No morphology, invented wall completion or manually drawn free space is applied.

![Directional conflict overlay](conflict_overlay_2p5cm.png)

## Verification and reproducibility

`verification.json` records successful checks of 90 copied source files, **1,441 source-bundle hashes plus 50 retained-baseline hashes**, all 18 frozen transforms/pose sets, 1,171 scan counts, the exact D3 exclusion audit and all ten raster products. The native renderer additionally checks original ranges against their serialized dataset, unchanged timestamps/odometry, transformed endpoint equivalence and mask count. Native hit totals equal retained valid endpoints at both resolutions.

An independent array-based audit reproduces every pixel of all five composition policies at both resolutions from the native counters. Targeted native tests recover a known rigid transform, reject an underconstrained single-wall fit, and exercise twelve occupied/free/unknown evidence cases. A fresh output directory reproduces all **20 PGM/YAML files byte-for-byte** from bundled original saves, selected poses, final transforms and fixed bounds.

For raster reproduction in an environment with the same ROS/Karto, Boost, TBB and Ceres libraries already installed:

```bash
cmake -S /path/to/A1_H2_merged_20261102_v1 -B /tmp/a1h2-rebuild -DCMAKE_PREFIX_PATH=/opt/ros/lyrical
cmake --build /tmp/a1h2-rebuild -j2
python3 /path/to/A1_H2_merged_20261102_v1/reproduce_map.py --build /tmp/a1h2-rebuild --output /tmp/a1h2-new-render
```

The output directory must be new. Rendering and fitting are native C++; Python scripts supply metadata, scientific analysis, plots and validation. No ROS node initialization or hardware access is used. The archive contains map-reproduction inputs; optional re-analysis of rear observations uses the hashed diagnostic caches identified in `rear_check.json`. Earlier analysis helpers are identified in `analysis_dependencies.json`.

`SHA256SUMS` seals the delivery files; the adjacent archive has a separate checksum and member validation record. This is a static occupancy-map candidate, not a newly optimized resumable pose graph. Sensor calibration and online odometry disagreement are unchanged. Source recordings and earlier sealed bundles remain intact.

Documentation checkpoint suggestion: **“Record refined A1–H2 merge and cross-date wall disagreements.”** Git operations remain with the user.
