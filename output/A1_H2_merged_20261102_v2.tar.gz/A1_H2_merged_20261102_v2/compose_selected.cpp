// Native two-epoch composition with explicit user-selected earlier wall regions.
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
namespace fs = std::filesystem;
void check(bool ok, const std::string &s) {if (!ok) {throw std::runtime_error(s);}}
struct Grid {int width, height; double resolution, x, y;};
struct Region {std::string name; double xmin, xmax, ymin, ymax; size_t selected{}, changed{}, old_occupied{}, later_occupied_removed{};};
struct Epoch {
  std::vector<unsigned> occupied, free, hits;
  std::vector<bool> supported, unresolved;
  std::vector<unsigned char> state;
  explicit Epoch(size_t n): occupied(n), free(n), hits(n), supported(n), unresolved(n), state(n,205) {}
};
void read_epoch(Epoch &b, const fs::path &in, std::string names, const Grid &g, std::set<std::string> &used) {
  std::replace(names.begin(),names.end(),',',' '); std::istringstream list(names); std::string name; size_t count=0;
  while (list>>name) {
    check(used.insert(name).second,"Repeated run"); ++count;
    std::ifstream f(in/(name+"_cells.csv")); check(bool(f),"Missing evidence"); std::string line; std::getline(f,line); std::set<size_t> seen;
    while (std::getline(f,line)) {
      std::replace(line.begin(),line.end(),',',' '); std::istringstream row(line); unsigned x,y,pass,hit,scans;
      check(bool(row>>x>>y>>pass>>hit>>scans),"Bad cell row");
      check(x<unsigned(g.width)&&y<unsigned(g.height)&&hit<=pass&&scans<=hit,"Invalid counters");
      const size_t i=size_t(y)*g.width+x; check(seen.insert(i).second,"Repeated cell");
      const bool occ=pass>2&&double(hit)>.1*pass;
      b.occupied[i]+=occ; b.free[i]+=pass>2&&!occ; b.hits[i]+=scans; b.supported[i]=b.supported[i]||(occ&&scans>=3);
    }
  }
  check(count>0,"Empty epoch");
  for (size_t i=0;i<b.state.size();++i) {
    const bool strong=b.supported[i]||(b.occupied[i]>=2&&b.hits[i]>=3);
    const bool weak=b.occupied[i]>0&&!strong, disputed=strong&&b.occupied[i]==1&&b.free[i]>=2;
    if (b.free[i]>0&&!weak) {b.state[i]=254;}
    if (strong) {b.state[i]=0;}
    if (disputed) {b.state[i]=205;}
    b.unresolved[i]=b.state[i]==205&&b.occupied[i]>0;
  }
}
void write_map(const fs::path &out, const std::string &name, const std::vector<unsigned char> &p, const Grid &g) {
  std::ofstream pgm(out/(name+".pgm"),std::ios::binary), yaml(out/(name+".yaml"));
  pgm<<"P5\n"<<g.width<<' '<<g.height<<"\n255\n";
  for (int y=g.height-1;y>=0;--y) {pgm.write(reinterpret_cast<const char*>(p.data()+size_t(y)*g.width),g.width);}
  yaml<<std::setprecision(17)<<"image: "<<name<<".pgm\nmode: trinary\nresolution: "<<g.resolution<<"\norigin: ["<<g.x<<", "<<g.y<<", 0]\nnegate: 0\noccupied_thresh: 0.65\nfree_thresh: 0.25\n";
  pgm.close(); yaml.close(); check(bool(pgm)&&bool(yaml),"Map write failure");
}
int main(int argc,char **argv) {try {
  check(argc==6,"Usage: compose_selected EVIDENCE NEW_OUTPUT EARLIER_RUNS LATER_RUNS REGIONS_CSV");
  const fs::path in=argv[1],out=argv[2]; check(fs::create_directory(out),"Output must be new");
  std::ifstream f(in/"grid.json"); check(bool(f),"No grid"); std::string meta((std::istreambuf_iterator<char>(f)),{});
  auto value=[&](const std::string &k) {const auto p=meta.find("\""+k+"\":"); check(p!=std::string::npos,"Missing grid field"); return std::stod(meta.substr(p+k.size()+3));};
  const auto op=meta.find("\"origin\":["); check(op!=std::string::npos,"No origin");
  std::string origin=meta.substr(op+10); std::replace(origin.begin(),origin.end(),',',' '); std::istringstream os(origin);
  Grid g{int(value("width")),int(value("height")),value("resolution"),0,0}; check(bool(os>>g.x>>g.y),"Bad origin");
  check(g.width>0&&g.height>0&&g.width<2000&&g.height<2000&&g.resolution>0,"Bad grid");
  std::ifstream rf(argv[5]); check(bool(rf),"Missing region policy"); std::string line; std::getline(rf,line); std::vector<Region> regions;
  while (std::getline(rf,line)) {
    std::replace(line.begin(),line.end(),',',' '); std::istringstream row(line); Region r; double offset;
    check(bool(row>>r.name>>r.xmin>>r.xmax>>r.ymin>>r.ymax>>offset),"Bad region");
    check(r.name.find_first_not_of("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_")==std::string::npos&&std::isfinite(r.xmin+r.xmax+r.ymin+r.ymax)&&r.xmin<r.xmax&&r.ymin<r.ymax,"Invalid region");
    regions.push_back(r);
  }
  check(!regions.empty(),"Empty region selection");
  const size_t n=size_t(g.width)*g.height; Epoch a(n),b(n); std::set<std::string> used;
  read_epoch(a,in,argv[3],g,used); read_epoch(b,in,argv[4],g,used);
  std::vector<unsigned char> before(n,205),map(n,205); size_t conflicts=0,changes=0;
  std::ofstream audit(out/"selected_regions.csv"); audit<<"x,y,region,earlier,later,before_preference,selected\n";
  for (size_t i=0;i<n;++i) {
    const bool ao=a.state[i]==0,bo=b.state[i]==0,af=a.state[i]==254,bf=b.state[i]==254;
    const bool cross=(ao&&bf)||(bo&&af); conflicts+=cross;
    if (!cross) {
      if (ao||bo) {before[i]=0;}
      else if (!a.unresolved[i]&&!b.unresolved[i]&&(af||bf)) {before[i]=254;}
    }
    map[i]=before[i]; int selected=-1;
    const double x=g.x+(double(i%g.width)+.5)*g.resolution,y=g.y+(double(i/g.width)+.5)*g.resolution;
    for (size_t k=0;k<regions.size();++k) {
      auto &r=regions[k]; if (x<r.xmin||x>=r.xmax||y<r.ymin||y>=r.ymax) {continue;}
      check(selected==-1,"Overlapping policy regions"); selected=int(k); map[i]=a.state[i];
      ++r.selected; r.changed+=before[i]!=map[i]; r.old_occupied+=ao; r.later_occupied_removed+=bo&&!ao;
      audit<<i%g.width<<','<<i/g.width<<','<<r.name<<','<<int(a.state[i])<<','<<int(b.state[i])<<','<<int(before[i])<<','<<int(map[i])<<'\n';
    }
    changes+=before[i]!=map[i];
  }
  audit.close(); check(bool(audit),"Selection audit failure");
  write_map(out,"map",map,g); write_map(out,"before_wall_preferences",before,g); write_map(out,"earlier",a.state,g); write_map(out,"later",b.state,g);
  std::ofstream stats(out/"summary.json"); stats<<"{\"runs\":"<<used.size()<<",\"cross_conflicts_before_preferences\":"<<conflicts<<",\"preference_changed_cells\":"<<changes<<",\"occupied\":"<<std::count(map.begin(),map.end(),0)<<",\"free\":"<<std::count(map.begin(),map.end(),254)<<",\"unknown\":"<<std::count(map.begin(),map.end(),205)<<",\"regions\":[";
  for (size_t k=0;k<regions.size();++k) {
    const auto &r=regions[k]; if (k) {stats<<',';}
    stats<<"{\"name\":\""<<r.name<<"\",\"selected_cells\":"<<r.selected<<",\"changed_cells\":"<<r.changed<<",\"earlier_occupied_cells\":"<<r.old_occupied<<",\"later_occupied_cells_not_retained\":"<<r.later_occupied_removed<<'}';
  }
  stats<<"]}\n"; stats.close(); check(bool(stats),"Summary write failure");
  std::cout<<"Selected earlier evidence in "<<regions.size()<<" regions; "<<changes<<" changed cells\n";
} catch (const std::exception &e) {std::cerr<<e.what()<<'\n'; return 1;} return 0;}
