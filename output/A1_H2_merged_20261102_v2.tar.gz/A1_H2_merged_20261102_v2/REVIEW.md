# Revised A1–H2 map: remove H1 trail and preserve earlier displaced walls

Prepared November 2, 2026, Asia/Seoul. This version implements both requested changes to the verified v1 merge. It still combines the latest `A1_D2_refined_20261102_v1` and `D3_H2_refined_20261102_v1` geometry: **18 passes and 1,171 saved scans**. The original captures, both refined source bundles, retained baseline and previous combined v1 bundle are unchanged.

**Current map:** [5 cm map.yaml](maps_5cm/map.yaml), with adjacent `map.pgm`. [2.5 cm diagnostic map](maps_2p5cm/map.yaml) is also supplied. Keep each YAML and PGM together. [Selected endpoints](selected_endpoints.png) show the cleaned sensor evidence; the occupancy maps are the deliverable grids.

![Revised map](map_preview_5cm.png)

## H1 trail removal

Exactly **75 H1 returns across all 42 saved H1 scans** are excluded using the audited scan ID, beam index and original range. The native renderer verifies these values and replaces each selected range with NaN **before ray tracing**. The entire ray contributes neither an occupied endpoint nor free-space clearing. No maximum-range replacement is used.

The audit is [H1_excluded_rays.csv](H1_excluded_rays.csv); the scope and semantics are in [H1_mapping_exclusion_policy.json](H1_mapping_exclusion_policy.json). This is an exact saved-data exclusion for H1 only, not a global sensor mask. It removes the reviewed near-field cluster around robot-frame (−0.010, +0.174) m, including its sparse companions. The inspected map region x = −0.90…−0.75 m, y = 3.85…4.85 m now contains **zero retained H1 endpoints**. Nearby measured wall returns remain.

All 42 H1 poses remain; H1 retains **10,994 valid endpoints**, down from 11,069. No new pose optimization or scan matching is performed. Therefore this change does not claim to reverse any influence the original returns may have had on upstream pose estimation.

![H1 exclusion before and after](H1_trail_before_after.png)

D3's existing exclusion remains exact: **1,206 rays**—1,194 dense-trail and 12 companion rays—are still ignored without free-space clearing. Its selected refined poses and 23,452 retained valid endpoints are unchanged. Both native resolutions emit an `excluded_rays.csv` proving the exact **1,281 D3+H1 scan/beam/range exclusions**.

For H1, native counters only decrease: the 5 cm grid removes 75 hits and 444 total cell-pass counts; the 2.5 cm grid removes 75 hits and 664 cell-pass counts. No new hits or clearing evidence are introduced. The merged occupancy classifications do not change from H1 removal alone, because this trail already produced zero occupied cells and its weak clearing evidence did not change the classification thresholds. Its disappearance is visible in the endpoint plot and verified in the underlying counters.

## Earlier geometry selected at the large-offset walls

The user's instruction selects the October 31 evidence at displaced walls. The selection includes every reviewed interior feature with an absolute median **front-LiDAR** cross-date offset of at least 2 cm, including the lower-left feature whose later support was weaker. This is an explicit source preference, not evidence that the earlier geometry is surveyed truth or that a wall physically moved.

| Figure region | Wall | Previously measured offset | Earlier source selected in merged-frame bounds, metres |
|---|---|---:|---|
| 1 | Upper-left horizontal | 2.70 cm | x [−1.88, −0.93), y [3.55, 3.82) |
| 2 | Upper-right horizontal | 5.86 cm | x [1.10, 2.04), y [3.44, 3.82) |
| 3 | Lower-left vertical | 4.37 cm | x [−1.26, −0.94), y [−0.01, 0.90) |

The bounds include each observed wall's full extent and the displaced later surface while avoiding unrelated neighboring structures. The authoritative policy is [earlier_wall_regions.csv](earlier_wall_regions.csv), with rationale in [selection_policy.json](selection_policy.json). A cell is selected when its center lies inside one of these envelopes.

**Within each region, the final cell equals the earlier layer exactly**, whether occupied, free or unknown. There is no fallback to the later surface inside these regions. This restores the earlier wall and prevents later occupied duplicates from surviving there. Unknown earlier cells remain unknown; no new wall is drawn or extrapolated.

Outside those three regions, the previous conservative composition rule is retained: direct occupied/free contradictions become unknown; other supported occupancy and observed-free evidence are retained with the same support thresholds. The two dates remain separate evidence layers. Their relative transform, selected trajectories and native grid bounds are unchanged. The frame remains saved C1 rotated +90 degrees, not surveyed drawing coordinates.

![Map comparison](map_comparison_5cm.png)

| Resolution | Changed cells versus v1 | Earlier occupied cells preserved in regions 1 / 2 / 3 | Later occupied cells not retained in regions 1 / 2 / 3 |
|---|---:|---:|---:|
| 5 cm | **91** | 23 / 27 / 22 | 14 / 17 / 8 |
| 2.5 cm | **339** | 76 / 61 / 56 | 37 / 64 / 7 |

The count of later occupied cells not retained includes cells where the previous conservative result was already unknown. It is not the number of deleted physical walls. The final 5 cm map has **1,043 occupied, 10,387 free and 190,167 unknown cells**; the 2.5 cm map has **2,558 occupied, 42,813 free and 759,222 unknown cells**. Full exports preserve sparse distant observations, hence their large unknown border. Figures crop only the display.

`before_wall_preferences.yaml` retains the H1-cleaned conservative composition for comparison. `earlier.yaml` and `later.yaml` expose the two evidence layers on the same grid. These are diagnostic layers, not alternatives to the requested main `map.yaml`; the later layer intentionally still records the later displaced surfaces. Likewise, the v1 report and maps are retained as history.

## Verification

- **1,860 source/baseline hashes** match: both refined source bundles, all sealed v1 files and the retained baseline. All **90 copied save/pose/ray/audit inputs** match both v1 and the original refined bundles.
- The 18 saved trajectories, registration and grid bounds are unchanged. Every native pose/sensor export matches v1. All **17 unaffected runs' native counters and rasters** match byte-for-byte at both resolutions. The complete earlier layer is identical to v1.
- Native H1 and D3 exclusions match all 1,281 audited triples exactly. A test deliberately supplying a wrong H1 range is rejected. The renderer verifies original serialized ranges, timestamps/odometry, rigid endpoint transforms and exclusion counts.
- An independent array-based audit reproduces all **eight raster products** from native counters. The selected regions equal the earlier layer exactly, and the composition rule outside them is unchanged. Tests cover occupied/free/unknown precedence and reject overlapping selection regions.
- A fresh output directory reproduces all **16 PGM/YAML files byte-for-byte**. The endpoint preview separately confirms zero retained H1 trail endpoints. Before/after figures were visually inspected.

Details: [verification.json](verification.json), [native_tests.json](native_tests.json), [reproduction.json](reproduction.json), and [endpoint_preview_audit.json](endpoint_preview_audit.json).

## Reproduction and continuation

The native C++ renderer/composer and the original serialized saves, selected poses, frozen registration, grid bounds and exclusion/region policies are included. In an environment with the same installed ROS/Karto, Boost and TBB libraries:

```bash
cmake -S /path/to/A1_H2_merged_20261102_v2 -B /tmp/a1h2-v2-build -DCMAKE_PREFIX_PATH=/opt/ros/lyrical
cmake --build /tmp/a1h2-v2-build -j2
python3 /path/to/A1_H2_merged_20261102_v2/reproduce_map.py --build /tmp/a1h2-v2-build --output /tmp/a1h2-v2-new-render
```

The output directory must be new. Python supplies metadata/subprocess glue and scientific checks/figures; native C++ performs range exclusion, ray rendering and map composition. No ROS initialization or hardware access is used.

For future derivatives, carry forward **both** `sources/D3_mapping_exclusion_policy.json` and `H1_mapping_exclusion_policy.json`, plus the earlier-wall selection policy. Keep the source bundles intact. `SHA256SUMS` seals this version; the adjacent archive has a checksum and member-validation record. This remains a static map product, not a newly optimized resumable pose graph.

Good documentation commit checkpoint after review: `docs: record H1 trail exclusion and earlier wall selection`. Changes remain uncommitted; all Git and hardware commands stay with the user.
