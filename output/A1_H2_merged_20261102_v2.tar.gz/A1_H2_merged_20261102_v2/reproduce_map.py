"""Minimal metadata/subprocess glue: native rendering and user-selected composition."""
from pathlib import Path
import argparse,json,math,subprocess,hashlib
H=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path);p.add_argument('--build',type=Path,default=H/'build');args=p.parse_args()
out=args.output.resolve() if args.output else H
if args.output:out.mkdir(parents=True,exist_ok=False)
runs=json.loads((H/'runs.json').read_text());reg=json.loads((H/'registration.json').read_text());bounds=json.loads((H/'render_bounds.json').read_text())
lines=[]
for r in runs:
 n=r['name'];t=reg['transforms'][n]
 lines.append(f'{n}\t{H/"inputs"/n/"saved"}\t{H/"runs"/n/"selected_poses.csv"}\t{t[0][2]:.17g}\t{t[1][2]:.17g}\t{math.atan2(t[1][0],t[0][0]):.17g}\n')
table=out/'render.tsv';table.write_text(''.join(lines));old=','.join(r['name'] for r in runs if r['batch']=='earlier');new=','.join(r['name'] for r in runs if r['batch']=='later');checks=[]
for res,label in [(.05,'5cm'),(.025,'2p5cm')]:
 e=out/('evidence_'+label);m=out/('maps_'+label)
 with (out/('render_'+label+'.log')).open('w') as log:
  subprocess.run([str(args.build.resolve()/'render_selected'),str(table),str(e),*map(str,bounds),str(res),str(H/'H1_excluded_rays.csv')],check=True,stdout=log,stderr=subprocess.STDOUT)
  subprocess.run([str(args.build.resolve()/'compose_selected'),str(e),str(m),old,new,str(H/'earlier_wall_regions.csv')],check=True,stdout=log,stderr=subprocess.STDOUT)
 if args.output:
  for name in ['map','before_wall_preferences','earlier','later']:
   for ext in ['pgm','yaml']:
    f=m/(name+'.'+ext);source=H/m.name/f.name;sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();ok=sha(f)==sha(source);checks.append(dict(file=str(f.relative_to(out)),sha256=sha(f),matched=ok));assert ok,str(f)
 print(label,(m/'summary.json').read_text().strip(),flush=True)
if args.output:
 (out/'reproduction.json').write_text(json.dumps(dict(all_matched=True,files=checks),indent=2)+'\n');print('PASS: 16 PGM/YAML files reproduce exactly')
