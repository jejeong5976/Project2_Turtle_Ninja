"""Independent scientific/data validation of native exclusions and region choices."""
from pathlib import Path
import json,csv,hashlib
import numpy as np
import yaml
from PIL import Image
H=Path(__file__).resolve().parent;R=H.parents[1];V1=H.with_name('A1_H2_merged_20261102_v1')
def sha(p):
 d=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):d.update(b)
 return d.hexdigest()
def read(p):return np.atleast_1d(np.genfromtxt(p,delimiter=',',names=True))
def img(p):return np.flipud(np.asarray(Image.open(p)))
integrity=[]
for g in json.loads((H/'source_integrity_before.json').read_text())['groups']:
 for f in g['files']:assert sha(R/f['path'])==f['sha256'],f['path']
 integrity.append(dict(group=g['batch'],files=len(g['files']),matched=True))
assert sha(H/'registration.json')==sha(V1/'registration.json') and sha(H/'render_bounds.json')==sha(V1/'render_bounds.json')
runs=json.loads((H/'runs.json').read_text());copies=[];counts=[]
for r in runs:
 n=r['name']
 for rel in [f'inputs/{n}/saved.data',f'inputs/{n}/saved.posegraph',f'runs/{n}/selected_poses.csv',f'runs/{n}/rays.csv',f'runs/{n}/audit.json']:
  assert sha(H/rel)==sha(V1/rel)==sha(Path(r['source_bundle'])/rel);copies.append(dict(path=rel,sha256=sha(H/rel)))
 a=json.loads((H/'runs'/n/'audit.json').read_text());counts.append(dict(run=n,scans=a['scans'],retained_endpoints=a['valid_endpoints']-(1206 if n=='D3' else 75 if n=='H1' else 0)))
assert sum(r['scans'] for r in counts)==1171
h1=read(H/'H1_excluded_rays.csv');d3=read(H/'sources/D3_excluded_rays.csv')
expected={('H1',int(a['scan_id']),int(a['beam_index'])):a['original_range_m'] for a in h1};expected.update({('D3',int(a['scan_id']),int(a['beam_index'])):a['original_range_m'] for a in d3});assert len(expected)==1281
assert len(h1)==75 and len(np.unique(h1['scan_id']))==42
regions=list(csv.DictReader((H/'earlier_wall_regions.csv').open()));products=[];changes=[]
for label in ['5cm','2p5cm']:
 e=H/('evidence_'+label);m=H/('maps_'+label);g=json.loads((e/'grid.json').read_text());shape=(g['height'],g['width']);native=list(csv.DictReader((e/'excluded_rays.csv').open()));got={(r['run'],int(r['scan_id']),int(r['beam_index'])):float(r['original_range_m']) for r in native};assert got==expected and len(native)==1281
 audit={r['run']:r for r in csv.DictReader((e/'audit.csv').open())};state={};unresolved={};h1_counter_removals={}
 for batch in ['earlier','later']:
  occ=[];free=[];hits=[];strongs=[]
  for r in runs:
   if r['batch']!=batch:continue
   n=r['name'];c=read(e/(n+'_cells.csv'));x=c['x'].astype(int);y=c['y'].astype(int);o=np.zeros(shape,int);f=np.zeros(shape,int);s=np.zeros(shape,int);k=(c['pass_count']>2)&(c['hit_count']>.1*c['pass_count']);o[y,x]=k;f[y,x]=(c['pass_count']>2)&~k;s[y,x]=c['distinct_scan_hits'].astype(int);occ.append(o);free.append(f);hits.append(s);strongs.append((o!=0)&(s>=3))
   count=next(z for z in counts if z['run']==n);assert int(audit[n]['scans'])==count['scans'] and int(audit[n]['valid_endpoints'])==count['retained_endpoints']==int(c['hit_count'].sum());assert float(audit[n]['max_transform_error_m'])<1e-9
   assert int(audit[n]['excluded_rays'])==(1206 if n=='D3' else 75 if n=='H1' else 0)
   for tail in ['_poses.csv','_sensor.txt']:assert sha(e/(n+tail))==sha(V1/e.name/(n+tail))
   if n!='H1':
    for tail in ['_cells.csv','.pgm']:assert sha(e/(n+tail))==sha(V1/e.name/(n+tail))
   else:
    previous=read(V1/e.name/'H1_cells.csv');px=previous['x'].astype(int);py=previous['y'].astype(int)
    for field in ['pass_count','hit_count','distinct_scan_hits']:
     was=np.zeros(shape,int);now=np.zeros(shape,int);was[py,px]=previous[field].astype(int);now[y,x]=c[field].astype(int);assert np.all(now<=was),field;h1_counter_removals[field]=int(np.sum(was-now))
    assert h1_counter_removals['hit_count']==75
  oc=np.sum(occ,axis=0);fr=np.sum(free,axis=0);strong=np.any(strongs,axis=0)|((oc>=2)&(np.sum(hits,axis=0)>=3));weak=(oc>0)&~strong;disputed=strong&(oc==1)&(fr>=2);v=np.full(shape,205,np.uint8);v[(fr>0)&~weak]=254;v[strong]=0;v[disputed]=205;state[batch]=v;unresolved[batch]=(v==205)&(oc>0)
 a=state['earlier'];b=state['later'];cross=((a==0)&(b==254))|((a==254)&(b==0));before=np.full(shape,205,np.uint8);before[(~unresolved['earlier'])&(~unresolved['later'])&((a==254)|(b==254))]=254;before[(a==0)|(b==0)]=0;before[cross]=205
 yy,xx=np.indices(shape);x=g['origin'][0]+(xx+.5)*g['resolution'];y=g['origin'][1]+(yy+.5)*g['resolution'];selected=before.copy();any_region=np.zeros(shape,bool);details=[]
 for r in regions:
  k=(x>=float(r['xmin']))&(x<float(r['xmax']))&(y>=float(r['ymin']))&(y<float(r['ymax']));assert not np.any(any_region&k);any_region|=k;selected[k]=a[k];details.append(dict(name=r['name'],cells=int(k.sum()),changed=int(np.sum(before[k]!=selected[k])),earlier_occupied=int(np.sum(a[k]==0)),later_occupied_not_retained=int(np.sum((b[k]==0)&(a[k]!=0)))))
 arrays={'earlier':a,'later':b,'before_wall_preferences':before,'map':selected}
 for name,want in arrays.items():
  d=yaml.safe_load((m/(name+'.yaml')).read_text());assert d['origin']==g['origin'] and d['resolution']==g['resolution'] and d['image']==name+'.pgm' and d['mode']=='trinary';actual=img(m/d['image']);assert np.array_equal(actual,want),name;products.append(dict(map=str((m/(name+'.yaml')).relative_to(H)),verified=True,occupied=int(np.sum(actual==0)),free=int(np.sum(actual==254)),unknown=int(np.sum(actual==205))))
 assert np.array_equal(selected[~any_region],before[~any_region]);assert np.array_equal(a,img(V1/('maps_'+label)/'earlier.pgm'))
 # The audited H1 trail contributes no retained endpoint and no occupied raster cells.
 k=(x>-.9)&(x<-.75)&(y>3.85)&(y<4.85);assert np.sum(selected[k]==0)==0
 changes.append(dict(resolution=label,earlier_regions=details,H1_counter_removals=h1_counter_removals,H1_removal_changed_conservative_pixels=int(np.sum(before!=img(V1/('maps_'+label)/'map.pgm'))),final_changed_pixels_vs_v1=int(np.sum(selected!=img(V1/('maps_'+label)/'map.pgm'))),outside_region_precedence_unchanged=True))
native=json.loads((H/'native_tests.json').read_text());assert native['passed']
result=dict(passed=True,source_integrity=integrity,copied_files=copies,scans=1171,runs=counts,D3_excluded_rays=1206,H1_excluded_rays=75,exact_exclusion_audits_match=True,all_original_poses_and_transforms_preserved=True,seventeen_unaffected_native_rasters_identical=True,earlier_layer_identical=True,products=products,changes=changes,native_tests_passed=True)
(H/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS:',sum(g['files'] for g in integrity),'source hashes;',len(copies),'copied inputs; 1281 exact exclusions; 8 maps; earlier-region precedence; unchanged other runs')
