// File-only Karto rendering. No ROS initialization, devices, publishers or solver.
// Transform deserialized objects in memory only; input archives are never saved.
#include <karto_sdk/Mapper.h>
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <array>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;
void require(bool ok, const std::string & message) {
  if (!ok) {throw std::runtime_error(message);}
}
class EvidenceGrid : public karto::OccupancyGrid {
public:
  using karto::OccupancyGrid::OccupancyGrid;
  using karto::OccupancyGrid::CreateFromScans;
  using karto::OccupancyGrid::GetCellHitsCounts;
  using karto::OccupancyGrid::GetCellPassCounts;
};
struct Run {
  std::string name, prefix, poses_path;
  double x{}, y{}, yaw{};
};

int main(int argc, char ** argv) {
  try {
    require(argc == 9, "Usage: render_saved_runs TRANSFORMS_TSV NEW_OUTPUT XMIN YMIN XMAX YMAX RESOLUTION H1_EXCLUSIONS_CSV");
    std::ifstream exclusion_input(argv[8]); require(bool(exclusion_input), "Missing H1 audit");
    std::map<std::pair<int, size_t>, double> h1_exclusions;
    std::string exclusion_line; std::getline(exclusion_input, exclusion_line);
    while (std::getline(exclusion_input, exclusion_line)) {
      std::replace(exclusion_line.begin(), exclusion_line.end(), ',', ' ');
      std::istringstream row(exclusion_line); int scan_id; size_t beam; double range, x, y;
      require(bool(row >> scan_id >> beam >> range >> x >> y) && scan_id >= 0 &&
        std::isfinite(range) && range > 0, "Invalid H1 exclusion");
      require(h1_exclusions.emplace(std::make_pair(scan_id, beam), range).second, "Duplicate H1 exclusion");
    }
    require(h1_exclusions.size() == 75, "H1 audit count differs");
    const fs::path out = argv[2];
    const double xmin = std::stod(argv[3]), ymin = std::stod(argv[4]);
    const double xmax = std::stod(argv[5]), ymax = std::stod(argv[6]);
    const double resolution = std::stod(argv[7]);
    require(std::isfinite(xmin) && std::isfinite(ymin) && std::isfinite(xmax) &&
      std::isfinite(ymax) && (resolution == .05 || resolution == .025), "Invalid grid arguments");
    const int width = static_cast<int>(std::ceil((xmax - xmin) / resolution)) + 1;
    const int height = static_cast<int>(std::ceil((ymax - ymin) / resolution)) + 1;
    require(width > 0 && height > 0 && width < 2000 && height < 2000, "Grid size outside limits");
    std::ifstream table(argv[1]); require(bool(table), "Missing transform table");
    std::vector<Run> runs; std::set<std::string> names; std::string line;
    while (std::getline(table, line)) {
      std::istringstream row(line); Run r;
      require(bool(row >> r.name >> r.prefix >> r.poses_path >> r.x >> r.y >> r.yaw), "Malformed transform row");
      require(std::isfinite(r.x) && std::isfinite(r.y) && std::isfinite(r.yaw) &&
        names.insert(r.name).second && r.name.find_first_not_of("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_") == std::string::npos,
        "Invalid transform or run name");
      runs.push_back(r);
    }
    require(!runs.empty() && runs.size() <= 20, "Invalid run count");
    require(fs::create_directory(out), "Output directory must be new");
    std::ofstream meta(out / "grid.json");
    meta << std::setprecision(17) << "{\"resolution\":" << resolution
         << ",\"origin\":[" << xmin << ',' << ymin << ",0],\"width\":" << width
         << ",\"height\":" << height << ",\"min_pass_through\":2,\"occupancy_threshold\":0.1}\n";
    meta.close(); require(bool(meta), "Grid metadata write failed");
    std::ofstream audit(out / "audit.csv");
    audit << "run,scans,range_entries,valid_endpoints,max_transform_error_m,occupied_cells,free_cells,unknown_cells,excluded_rays\n";
    std::ofstream excluded_audit(out / "excluded_rays.csv");
    excluded_audit << std::setprecision(17) << "run,scan_id,beam_index,original_range_m\n";
    for (const auto & run : runs) {
      karto::Dataset dataset;
      karto::Mapper mapper;
      mapper.LoadFromFile(run.prefix + ".posegraph");
      dataset.LoadFromFile(run.prefix + ".data");
      require(dataset.GetLasers().size() == 1, "Expected one saved front laser model");
      for (auto * object : dataset.GetLasers()) {
        auto * laser = dynamic_cast<karto::LaserRangeFinder *>(object);
        require(laser != nullptr, "Non-laser model");
        karto::SensorManager::GetInstance()->RegisterSensor(laser, true);
        std::ofstream info(out / (run.name + "_sensor.txt"));
        info << std::setprecision(17) << "offset=" << laser->GetOffsetPose()
             << "\nminimum_range=" << laser->GetMinimumRange()
             << "\nmaximum_range=" << laser->GetMaximumRange()
             << "\nrange_threshold=" << laser->GetRangeThreshold()
             << "\nminimum_angle=" << laser->GetMinimumAngle()
             << "\nmaximum_angle=" << laser->GetMaximumAngle()
             << "\nangular_resolution=" << laser->GetAngularResolution() << '\n';
        info.close(); require(bool(info), "Sensor write failed");
      }
      const auto scans = mapper.GetAllProcessedScans();
      require(!scans.empty() && scans.size() < 2000, "Invalid saved scan count");
      std::ifstream pose_input(run.poses_path);require(bool(pose_input),"Missing selected poses");
      std::string pose_line;std::getline(pose_input,pose_line);std::vector<std::array<double,8>> selected;
      while(std::getline(pose_input,pose_line)) {
        std::replace(pose_line.begin(),pose_line.end(),',',' ');std::istringstream row(pose_line);std::array<double,8> p{};
        for(auto&v:p){require(bool(row>>v)&&std::isfinite(v),"Bad selected pose");}
        require(p[0]==double(selected.size()),"Selected scan order differs");selected.push_back(p);
      }
      require(selected.size()==scans.size(),"Selected pose count differs");size_t excluded=0;
      EvidenceGrid grid(width, height, {xmin, ymin}, resolution);
      std::vector<unsigned> scan_hits(width * height, 0);
      const double c = std::cos(run.yaw), s = std::sin(run.yaw);
      size_t range_entries = 0, endpoints = 0; double maximum_error = 0;
      std::ofstream poses(out / (run.name + "_poses.csv"));
      poses << std::setprecision(17) << "scan_id,x_m,y_m,yaw_rad,sensor_x_m,sensor_y_m\n";
      for (auto * scan : scans) {
        const auto found = dataset.GetData().find(scan->GetUniqueId());
        require(found != dataset.GetData().end(), "Graph scan missing from dataset");
        const auto * original = dynamic_cast<const karto::LocalizedRangeScan *>(found->second);
        require(original != nullptr, "Wrong saved data type");
        auto ranges = scan->GetRangeReadingsVector();
        const auto other = original->GetRangeReadingsVector();
        require(ranges.size() == other.size() && !ranges.empty(), "Range size mismatch");
        for (size_t i = 0; i < ranges.size(); ++i) {
          require(ranges[i] == other[i] || (std::isnan(ranges[i]) && std::isnan(other[i])), "Range mismatch");
        }
        range_entries += ranges.size();
        const auto& chosen=selected.at(scan->GetUniqueId());const auto odom=scan->GetOdometricPose();
        require(chosen[1]==scan->GetTime()&&chosen[5]==odom.GetX()&&chosen[6]==odom.GetY()&&chosen[7]==odom.GetHeading(),"Selected input stamps/odometry changed");
        if(run.name=="D3") {
          const auto*laser=scan->GetLaserRangeFinder();const auto mount=laser->GetOffsetPose();
          for(size_t j=0;j<ranges.size();++j){const double r=ranges[j];if(!std::isfinite(r)||r<laser->GetMinimumRange()||r>laser->GetRangeThreshold())continue;
            const double a=mount.GetHeading()+laser->GetMinimumAngle()+j*laser->GetAngularResolution();
            const double bx=mount.GetX()+r*std::cos(a),by=mount.GetY()+r*std::sin(a);
            if((bx>.13&&bx<.17&&by>.08&&by<.13)||(bx>.075&&bx<.09&&by>.16&&by<.185)){
              excluded_audit << run.name << ',' << scan->GetUniqueId() << ',' << j << ',' << r << '\n';
              ranges[j]=std::numeric_limits<double>::quiet_NaN();++excluded;
            }
          }
          scan->SetRangeReadings(ranges);
        }
        if (run.name == "H1") {
          for (size_t beam = 0; beam < ranges.size(); ++beam) {
            const auto entry = h1_exclusions.find({scan->GetUniqueId(), beam});
            if (entry == h1_exclusions.end()) {continue;}
            require(ranges[beam] == entry->second, "H1 scan/beam/range differs from reviewed audit");
            excluded_audit << run.name << ',' << scan->GetUniqueId() << ',' << beam << ',' << ranges[beam] << '\n';
            ranges[beam] = std::numeric_limits<double>::quiet_NaN(); ++excluded;
          }
          scan->SetRangeReadings(ranges);
        }
        scan->SetCorrectedPose({chosen[2],chosen[3],chosen[4]});
        const auto before = scan->GetPointReadings(true);
        const auto p = scan->GetCorrectedPose();
        require(std::isfinite(p.GetX()) && std::isfinite(p.GetY()) && std::isfinite(p.GetHeading()), "Nonfinite pose");
        scan->SetCorrectedPose({c * p.GetX() - s * p.GetY() + run.x,
          s * p.GetX() + c * p.GetY() + run.y, p.GetHeading() + run.yaw});
        const auto & after = scan->GetPointReadings(true);
        require(before.size() == after.size(), "Transform changed endpoint count");
        std::set<int> hit_cells;
        for (size_t i = 0; i < after.size(); ++i) {
          if (!std::isfinite(after[i].GetX()) || !std::isfinite(after[i].GetY())) {continue;}
          const double ex = c * before[i].GetX() - s * before[i].GetY() + run.x;
          const double ey = s * before[i].GetX() + c * before[i].GetY() + run.y;
          maximum_error = std::max(maximum_error, std::hypot(ex - after[i].GetX(), ey - after[i].GetY()));
          const auto index = grid.WorldToGrid(after[i]);
          require(grid.IsValidGridIndex(index), "Valid endpoint outside requested bounds");
          hit_cells.insert(index.GetY() * width + index.GetX()); ++endpoints;
        }
        for (const int cell : hit_cells) {++scan_hits[cell];}
        const auto & q = scan->GetCorrectedPose(); const auto sensor = scan->GetSensorPose();
        poses << scan->GetUniqueId() << ',' << q.GetX() << ',' << q.GetY() << ',' << q.GetHeading()
              << ',' << sensor.GetX() << ',' << sensor.GetY() << '\n';
      }
      require(maximum_error < 1e-9, "Rigid transform equivariance check failed");
      require(excluded==(run.name=="D3"?1206:(run.name=="H1"?75:0)),"Reviewed exclusion differs");
      grid.SetMinPassThrough(2); grid.SetOccupancyThreshold(.1); grid.CreateFromScans(scans);
      std::ofstream cells(out / (run.name + "_cells.csv"));
      cells << "x,y,pass_count,hit_count,distinct_scan_hits\n";
      std::ofstream image(out / (run.name + ".pgm"), std::ios::binary);
      image << "P5\n" << width << ' ' << height << "\n255\n";
      size_t occupied = 0, free = 0, unknown = 0;
      for (int y = height - 1; y >= 0; --y) {
        for (int x = 0; x < width; ++x) {
          const auto passes = grid.GetCellPassCounts()->GetValue({x, y});
          const auto hits = grid.GetCellHitsCounts()->GetValue({x, y});
          const auto value = grid.GetValue({x, y}); unsigned char pixel = 205;
          const bool is_occupied = passes > 2 && static_cast<double>(hits) / passes > .1;
          const bool is_free = passes > 2 && !is_occupied;
          require((value == karto::GridStates_Occupied) == is_occupied &&
            (value == karto::GridStates_Free) == is_free, "Counter/native classification mismatch");
          if (is_occupied) {pixel = 0; ++occupied;} else if (is_free) {pixel = 254; ++free;} else {++unknown;}
          if (passes || hits || scan_hits[y * width + x]) {
            cells << x << ',' << y << ',' << passes << ',' << hits << ',' << scan_hits[y * width + x] << '\n';
          }
          image.put(static_cast<char>(pixel));
        }
      }
      poses.close(); cells.close(); image.close();
      require(bool(poses) && bool(cells) && bool(image), "Run output failed");
      audit << std::setprecision(17) << run.name << ',' << scans.size() << ',' << range_entries << ',' << endpoints
            << ',' << maximum_error << ',' << occupied << ',' << free << ',' << unknown << ',' << excluded << '\n';
      std::cout << run.name << ": " << scans.size() << " scans, " << endpoints << " endpoints; rigid transform checked\n";
    }
    audit.close(); require(bool(audit), "Audit output failed");
    excluded_audit.close(); require(bool(excluded_audit), "Exclusion audit output failed");
  } catch (const karto::Exception & e) {std::cerr << e.GetErrorMessage() << '\n'; return 1;}
  catch (const std::exception & e) {std::cerr << e.what() << '\n'; return 1;}
  return 0;
}
