"""File-only integration checks of native region precedence and audited exclusions."""
from pathlib import Path
import tempfile,subprocess,json,csv
import numpy as np
from PIL import Image
H=Path(__file__).resolve().parent;checks={}
with tempfile.TemporaryDirectory(prefix='a1h2-v2-test-') as td:
 p=Path(td);e=p/'evidence';e.mkdir();(e/'grid.json').write_text('{"width":12,"height":1,"resolution":0.05,"origin":[0,0,0]}')
 states={'a':['O','F','O','F','U','O','W','O','O','F','U','O'],'b':['F','O','F','O','O','U','F','W','F','F','U','O']}
 for name,ss in states.items():
  lines=['x,y,pass_count,hit_count,distinct_scan_hits\n']
  for x,s in enumerate(ss):
   if s!='U':lines.append(f'{x},0,'+{'O':'4,4,4','F':'4,0,0','W':'4,1,1'}[s]+'\n')
  (e/(name+'_cells.csv')).write_text(''.join(lines))
 regions=p/'regions.csv';regions.write_text('name,xmin,xmax,ymin,ymax,offset_cm\ntest_region,0.1,0.4,0,0.1,3\n')
 subprocess.run([str(H/'build/compose_selected'),str(e),str(p/'maps'),'a','b',str(regions)],check=True,capture_output=True)
 actual=np.asarray(Image.open(p/'maps/map.pgm'))[0];expected=[205,205,0,254,205,0,205,0,205,254,205,0];assert np.array_equal(actual,expected);checks['earlier_occupied_free_unknown_preserved_inside_only']=True
 regions.write_text(regions.read_text()+'overlap,0.1,0.3,0,0.1,3\n')
 bad=subprocess.run([str(H/'build/compose_selected'),str(e),str(p/'bad'),'a','b',str(regions)],capture_output=True,text=True);assert bad.returncode!=0 and 'Overlapping' in bad.stderr;checks['overlapping_regions_rejected']=True
 # Wrong original range must fail before any map can be produced for H1.
 lines=[x for x in (H/'render.tsv').read_text().splitlines() if x.startswith('H1\t')];assert len(lines)==1;(p/'h1.tsv').write_text(lines[0]+'\n')
 rows=list(csv.reader((H/'H1_excluded_rays.csv').open()));rows[1][2]=str(float(rows[1][2])+.001)
 with (p/'bad_mask.csv').open('w',newline='') as f:csv.writer(f).writerows(rows)
 bounds=json.loads((H/'render_bounds.json').read_text());bad=subprocess.run([str(H/'build/render_selected'),str(p/'h1.tsv'),str(p/'bad_render'),*map(str,bounds),'0.05',str(p/'bad_mask.csv')],capture_output=True,text=True)
 assert bad.returncode!=0 and 'H1 scan/beam/range differs' in bad.stderr;checks['wrong_H1_scan_beam_range_rejected']=True
(H/'native_tests.json').write_text(json.dumps(dict(passed=True,checks=checks),indent=2)+'\n');print(checks)
